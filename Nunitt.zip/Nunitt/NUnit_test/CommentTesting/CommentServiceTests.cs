﻿using Moq;
using SimpleTwitter.DTOs.Comment;
using SimpleTwitter.Interfaces.Comments;
using SimpleTwitter.Interfaces.Twitter;
using SimpleTwitter.Models;
using SimpleTwitter.Services.CommentServices;

namespace NUnit_test.CommentTesting
{
    [TestFixture]
    public class CommentServiceTests
    {
        private Mock<ICommentRepository> _mockCommentRepository;
        private Mock<ITwitterPostRepository> _mockTwitterPostRepository;
        private CommentService _commentService;

        [SetUp]
        public void Setup()
        {
            _mockCommentRepository = new Mock<ICommentRepository>();
            _mockTwitterPostRepository = new Mock<ITwitterPostRepository>();
            _commentService = new CommentService(_mockCommentRepository.Object, _mockTwitterPostRepository.Object);
        }

        [Test]
        public async Task AddCommentAsync_ValidComment_AddsCommentSuccessfully()
        {
            // Arrange
            var createCommentDto = new CreateCommentDto
            {
                TwitterId = Guid.NewGuid(),
                Username = "testuser",
                Content = "This is a test comment."
            };
            var twitterPost = new TwitterPost { TwitterId = createCommentDto.TwitterId };

            _mockTwitterPostRepository.Setup(repo => repo.GetTwitterPostByIdAsync(createCommentDto.TwitterId))
                                      .ReturnsAsync(twitterPost);

            // Act
            await _commentService.AddCommentAsync(createCommentDto, "testuser");

            // Assert
            _mockCommentRepository.Verify(repo => repo.AddCommentAsync(It.Is<Comment>(c =>
                c.TwitterId == createCommentDto.TwitterId &&
                c.Username == createCommentDto.Username &&
                c.Content == createCommentDto.Content
            )), Times.Once);
        }

        [Test]
        public void AddCommentAsync_TwitterPostNotFound_ThrowsException()
        {
            // Arrange
            var createCommentDto = new CreateCommentDto
            {
                TwitterId = Guid.NewGuid(),
                Username = "testuser",
                Content = "This is a test comment."
            };

            _mockTwitterPostRepository.Setup(repo => repo.GetTwitterPostByIdAsync(createCommentDto.TwitterId))
                                      .ReturnsAsync((TwitterPost)null);

            // Act & Assert
            var ex = Assert.ThrowsAsync<Exception>(() => _commentService.AddCommentAsync(createCommentDto, "testuser"));
            Assert.AreEqual("Twitter post not found.", ex.Message);
        }

        [Test]
        public void AddCommentAsync_UsernameMismatch_ThrowsUnauthorizedAccessException()
        {
            // Arrange
            var createCommentDto = new CreateCommentDto
            {
                TwitterId = Guid.NewGuid(),
                Username = "otheruser",
                Content = "This is a test comment."
            };
            var twitterPost = new TwitterPost { TwitterId = createCommentDto.TwitterId };

            _mockTwitterPostRepository.Setup(repo => repo.GetTwitterPostByIdAsync(createCommentDto.TwitterId))
                                      .ReturnsAsync(twitterPost);

            // Act & Assert
            var ex = Assert.ThrowsAsync<UnauthorizedAccessException>(() => _commentService.AddCommentAsync(createCommentDto, "testuser"));
            Assert.AreEqual("Username does not match the logged-in user.", ex.Message);
        }

        [Test]
        public void AddCommentAsync_ContentExceedsLimit_ThrowsArgumentException()
        {
            // Arrange
            var createCommentDto = new CreateCommentDto
            {
                TwitterId = Guid.NewGuid(),
                Username = "testuser",
                Content = new string('A', 141)  // Exceeding 140 characters
            };
            var twitterPost = new TwitterPost { TwitterId = createCommentDto.TwitterId };

            _mockTwitterPostRepository.Setup(repo => repo.GetTwitterPostByIdAsync(createCommentDto.TwitterId))
                                      .ReturnsAsync(twitterPost);

            // Act & Assert
            var ex = Assert.ThrowsAsync<ArgumentException>(() => _commentService.AddCommentAsync(createCommentDto, "testuser"));
            Assert.AreEqual("Comment cannot exceed 140 characters.", ex.Message);
        }

        [Test]
        public async Task GetCommentsByTwitterIdAsync_ValidTwitterId_ReturnsComments()
        {
            // Arrange
            var twitterId = Guid.NewGuid();
            var comments = new List<Comment>
            {
                new Comment { Id = Guid.NewGuid(), TwitterId = twitterId, Username = "user1", Content = "Comment 1", CreatedAt = DateTime.UtcNow },
                new Comment { Id = Guid.NewGuid(), TwitterId = twitterId, Username = "user2", Content = "Comment 2", CreatedAt = DateTime.UtcNow }
            };

            _mockCommentRepository.Setup(repo => repo.GetCommentsByTwitterIdAsync(twitterId)).ReturnsAsync(comments);

            // Act
            var result = await _commentService.GetCommentsByTwitterIdAsync(twitterId);

            // Assert
            Assert.IsInstanceOf<IEnumerable<CommentDto>>(result);
            Assert.AreEqual(comments.Count, result.Count());
            Assert.AreEqual(comments[0].Content, result.ElementAt(0).Content);
            Assert.AreEqual(comments[1].Content, result.ElementAt(1).Content);
        }

        [Test]
        public async Task GetCommentsByTwitterIdAsync_NoComments_ReturnsEmptyList()
        {
            // Arrange
            var twitterId = Guid.NewGuid();
            _mockCommentRepository.Setup(repo => repo.GetCommentsByTwitterIdAsync(twitterId)).ReturnsAsync(new List<Comment>());

            // Act
            var result = await _commentService.GetCommentsByTwitterIdAsync(twitterId);

            // Assert
            Assert.IsEmpty(result);
        }
    }
}
