﻿using Moq;
using Microsoft.AspNetCore.Mvc;
using SimpleTwitter.Controllers;
using SimpleTwitter.DTOs.Comment;
using SimpleTwitter.Services.CommentServices;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;

namespace NUnit_test.CommentTesting
{
    [TestFixture]
    public class CommentControllerTests
    {
        private CommentController _controller;
        private Mock<ICommentService> _mockCommentService;

        [SetUp]
        public void Setup()
        {
            _mockCommentService = new Mock<ICommentService>();
            _controller = new CommentController(_mockCommentService.Object);
        }

        [Test]
        public async Task CreateComment_UserAuthenticated_ReturnsOkResult()
        {
            // Arrange
            var createCommentDto = new CreateCommentDto { Content = "Test comment", TwitterId = Guid.NewGuid() };
            var username = "testuser";

            var claims = new List<Claim> { new Claim(ClaimTypes.Name, username) };
            var identity = new ClaimsIdentity(claims, "TestAuthType");
            var claimsPrincipal = new ClaimsPrincipal(identity);
            _controller.ControllerContext.HttpContext = new DefaultHttpContext { User = claimsPrincipal };

            _mockCommentService.Setup(service => service.AddCommentAsync(createCommentDto, username)).Returns(Task.CompletedTask);

            // Act
            var result = await _controller.CreateComment(createCommentDto);

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            Assert.AreEqual("Comment created successfully.", ((OkObjectResult)result).Value);
            _mockCommentService.Verify(service => service.AddCommentAsync(createCommentDto, username), Times.Once);
        }

        [Test]
        public async Task CreateComment_UserNotAuthenticated_ReturnsUnauthorizedResult()
        {
            // Arrange
            var createCommentDto = new CreateCommentDto { Content = "Test comment", TwitterId = Guid.NewGuid() };
            _controller.ControllerContext.HttpContext = new DefaultHttpContext { User = new ClaimsPrincipal() }; // No claims

            // Act
            var result = await _controller.CreateComment(createCommentDto);

            // Assert
            Assert.IsInstanceOf<UnauthorizedObjectResult>(result);
            Assert.AreEqual("User is not authenticated.", ((UnauthorizedObjectResult)result).Value);
        }

        [Test]
        public async Task CreateComment_ExceptionThrown_ReturnsBadRequest()
        {
            // Arrange
            var createCommentDto = new CreateCommentDto { Content = "Test comment", TwitterId = Guid.NewGuid() };
            var username = "testuser";

            var claims = new List<Claim> { new Claim(ClaimTypes.Name, username) };
            var identity = new ClaimsIdentity(claims, "TestAuthType");
            var claimsPrincipal = new ClaimsPrincipal(identity);
            _controller.ControllerContext.HttpContext = new DefaultHttpContext { User = claimsPrincipal };

            _mockCommentService.Setup(service => service.AddCommentAsync(createCommentDto, username))
                               .ThrowsAsync(new Exception("An error occurred"));

            // Act
            var result = await _controller.CreateComment(createCommentDto);

            // Assert
            Assert.IsInstanceOf<BadRequestObjectResult>(result);
            Assert.AreEqual("An error occurred", ((BadRequestObjectResult)result).Value);
        }

        [Test]
        public async Task GetCommentsByTwitterId_ValidTwitterId_ReturnsOkWithComments()
        {
            // Arrange
            var twitterId = Guid.NewGuid();
            var comments = new List<CommentDto>
            {
                new CommentDto { Content = "Test comment 1", Username = "user1" },
                new CommentDto { Content = "Test comment 2", Username = "user2" }
            };

            _mockCommentService.Setup(service => service.GetCommentsByTwitterIdAsync(twitterId)).ReturnsAsync(comments);

            // Act
            var result = await _controller.GetCommentsByTwitterId(twitterId);

            // Assert
            var okResult = result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.IsInstanceOf<List<CommentDto>>(okResult.Value);
            Assert.AreEqual(comments.Count, ((List<CommentDto>)okResult.Value).Count);
            _mockCommentService.Verify(service => service.GetCommentsByTwitterIdAsync(twitterId), Times.Once);
        }

        [Test]
        public async Task GetCommentsByTwitterId_ExceptionThrown_ReturnsBadRequest()
        {
            // Arrange
            var twitterId = Guid.NewGuid();
            _mockCommentService.Setup(service => service.GetCommentsByTwitterIdAsync(twitterId))
                               .ThrowsAsync(new Exception("An error occurred"));

            // Act
            var result = await _controller.GetCommentsByTwitterId(twitterId);

            // Assert
            Assert.IsInstanceOf<BadRequestObjectResult>(result);
            Assert.AreEqual("An error occurred", ((BadRequestObjectResult)result).Value);
        }
    }
}
