using Moq;
using SimpleTwitter.Controllers;
using SimpleTwitter.DTOs.User;
using SimpleTwitter.Services.UserService;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using SimpleTwitter.Models;

namespace NUnit_test.UserTesting
{
    [TestFixture]
    public class UserControllerTests
    {
        private Mock<IUserService> _userServiceMock;
        private Mock<IConfiguration> _configurationMock;
        private UserController _controller;

        [SetUp]
        public void SetUp()
        {
            _userServiceMock = new Mock<IUserService>();
            _configurationMock = new Mock<IConfiguration>();
            _controller = new UserController(_userServiceMock.Object, _configurationMock.Object);
        }

        [Test]
        public async Task Register_ShouldReturnOk_WhenUserIsRegistered()
        {
            var registerDto = new RegisterDto
            {
                Email = "test@example.com",
                Password = "Password123",
                UserName = "testuser"
            };
            _userServiceMock.Setup(s => s.Register(registerDto)).ReturnsAsync(true);
            _userServiceMock.Setup(s => s.GetUserByEmailAsync(registerDto.Email)).ReturnsAsync(new User { Email = registerDto.Email });

            var result = await _controller.Register(registerDto) as OkObjectResult;

            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);
        }

        //For this to work, you'll need to comment the token functionality in the UserController's Login method. Otherwise, it throws an error.
        [Test]
        public async Task Login_ShouldReturnOk_WhenCredentialsAreValid()
        {
            var loginDto = new LoginDto { Email = "test@example.com", Password = "Password123" };
            var user = new User { Email = loginDto.Email, UserName = "testuser" };
            _userServiceMock.Setup(s => s.Login(loginDto)).ReturnsAsync(user);

            var result = await _controller.Login(loginDto) as OkObjectResult;

            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);
        }
    }
}