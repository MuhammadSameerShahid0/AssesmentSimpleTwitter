﻿using Moq;
using SimpleTwitter.Interfaces;
using SimpleTwitter.Services.UserService;
using SimpleTwitter.DTOs.User;
using SimpleTwitter.Models;

namespace NUnit_test.UserTesting
{
    [TestFixture]
    public class UserServiceTests
    {
        private Mock<IUserRepository> _userRepositoryMock;
        private Mock<IUserService> _userServiceMock;
        private UserService _userService;

        [SetUp]
        public void SetUp()
        {
            _userRepositoryMock = new Mock<IUserRepository>();
            _userServiceMock = new Mock<IUserService>();
            _userService = new UserService(_userRepositoryMock.Object);
        }

        [Test]
        public async Task Register_ShouldReturnTrue_WhenUserIsRegistered()
        {
            var registerDto = new RegisterDto { Email = "test@example.com", Password = "Password123", UserName = "testuser" };
            _userRepositoryMock.Setup(r => r.RegisterUserAsync(It.IsAny<User>())).ReturnsAsync(true);

            var result = await _userService.Register(registerDto);

            Assert.IsTrue(result);
        }

        [Test]
        public async Task Login_ShouldReturnUser_WhenCredentialsAreValid()
        {
            // Arrange
            var loginDto = new LoginDto { Email = "test@example.com", Password = "Password123" };

            // Create password hash and salt using the service
            byte[] passwordHash, passwordSalt;
            _userService.CreatePasswordHash(loginDto.Password, out passwordHash, out passwordSalt);

            // Create a mock user with hashed password and salt
            var user = new User
            {
                Email = loginDto.Email,
                UserName = "testuser",
                PasswordHash = passwordHash, // Set the hashed password
                PasswordSalt = passwordSalt  // Set the salt
            };

            // Setup the repository mock to return the user
            _userRepositoryMock.Setup(r => r.GetUserByEmailAsync(loginDto.Email)).ReturnsAsync(user);

            // Act
            var result = await _userService.Login(loginDto);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(loginDto.Email, result.Email);
        }

    }
}