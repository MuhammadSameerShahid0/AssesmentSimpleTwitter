﻿using Moq;
using SimpleTwitter.DTOs.TwitterPost;
using SimpleTwitter.Interfaces.Twitter;
using SimpleTwitter.Models;
using SimpleTwitter.Services.TwitterPostServices;

namespace NUnit_test.TwitterPostTesting
{
    [TestFixture]
    public class TwitterPostServiceTests
    {
        private TwitterPostService _service;
        private Mock<ITwitterPostRepository> _mockRepo;

        [SetUp]
        public void Setup()
        {
            _mockRepo = new Mock<ITwitterPostRepository>();
            _service = new TwitterPostService(_mockRepo.Object);
        }

        [Test]
        public async Task AddTwitterPostAsync_ValidData_CallsRepositoryAddMethod()
        {
            // Arrange
            var postDto = new TwitterPostDto { Title = "New Post", Description = "Post Description" };
            var userId = Guid.NewGuid();

            // Act
            await _service.AddTwitterPostAsync(postDto, userId);

            // Assert
            _mockRepo.Verify(repo => repo.AddTwitterPostAsync(It.Is<TwitterPost>(post =>
                post.UserId == userId &&
                post.Title == postDto.Title &&
                post.Description == postDto.Description)), Times.Once);
        }

        [Test]
        public async Task GetAllPostsAsync_ReturnsListOfTwitterPostDtos()
        {
            // Arrange
            var posts = new List<TwitterPost>
            {
                new TwitterPost { Title = "Post 1", Description = "Description 1" },
                new TwitterPost { Title = "Post 2", Description = "Description 2" }
            };
            _mockRepo.Setup(repo => repo.GetAllPostsAsync()).ReturnsAsync(posts);

            // Act
            var result = await _service.GetAllPostsAsync();

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(2, result.Count());
            Assert.AreEqual("Post 1", result.First().Title);
        }
    }
}
