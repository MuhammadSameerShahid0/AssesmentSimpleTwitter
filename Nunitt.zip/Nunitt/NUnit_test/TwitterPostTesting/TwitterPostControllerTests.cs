﻿using Moq;
using Microsoft.AspNetCore.Mvc;
using SimpleTwitter.Controllers;
using SimpleTwitter.DTOs.TwitterPost;
using SimpleTwitter.Interfaces.Twitter;
using SimpleTwitter.Models;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using SimpleTwitter.Services.TwitterPostServices;

namespace NUnit_test.TwitterPostTesting
{
    [TestFixture]
    public class TwitterPostControllerTests
    {
        private TwitterPostController _controller;
        private Mock<ITwitterPostRepository> _mockRepo;
        private Mock<ITwitterPostService> _mockService;

        [SetUp]
        public void Setup()
        {
            _mockRepo = new Mock<ITwitterPostRepository>();
            _mockService = new Mock<ITwitterPostService>();
            _controller = new TwitterPostController(_mockRepo.Object, _mockService.Object);
        }

        [Test]
        public async Task CreatePost_ValidPost_ReturnsOkResult()
        {
            // Arrange
            var twitterPostDto = new TwitterPostDto { Title = "Test Title", Description = "Test Description" };
            var userId = Guid.NewGuid();
            var claims = new List<Claim> { new Claim(ClaimTypes.NameIdentifier, userId.ToString()) };
            var identity = new ClaimsIdentity(claims, "TestAuthType");
            var claimsPrincipal = new ClaimsPrincipal(identity);
            _controller.ControllerContext.HttpContext = new DefaultHttpContext { User = claimsPrincipal };

            // Act
            var result = await _controller.CreatePost(twitterPostDto);

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            _mockRepo.Verify(repo => repo.AddTwitterPostAsync(It.IsAny<TwitterPost>()), Times.Once);
        }

        [Test]
        public async Task CreatePost_UserNotAuthenticated_ReturnsUnauthorizedResult()
        {
            // Arrange
            var twitterPostDto = new TwitterPostDto { Title = "Test Title", Description = "Test Description" };
            _controller.ControllerContext.HttpContext = new DefaultHttpContext { User = new ClaimsPrincipal() }; // No claims

            // Act
            var result = await _controller.CreatePost(twitterPostDto);

            // Assert
            Assert.IsInstanceOf<UnauthorizedObjectResult>(result);
            Assert.AreEqual("User is not authenticated.", ((UnauthorizedObjectResult)result).Value);
        }

        [Test]
        public async Task GetAllPosts_ReturnsOkWithListOfPosts()
        {
            // Arrange
            var posts = new List<TwitterPostDto>
            {
                new TwitterPostDto { Title = "Post 1", Description = "Description 1" },
                new TwitterPostDto { Title = "Post 2", Description = "Description 2" }
            };
            _mockService.Setup(service => service.GetAllPostsAsync()).ReturnsAsync(posts);

            // Act
            var result = await _controller.GetAllPosts();

            // Assert
            var okResult = result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.IsInstanceOf<List<TwitterPostDto>>(okResult.Value);
            Assert.AreEqual(posts.Count, ((List<TwitterPostDto>)okResult.Value).Count);
        }
    }
}
